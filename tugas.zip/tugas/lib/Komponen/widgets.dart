typedef CallbackSetting = void Function(String, int);
